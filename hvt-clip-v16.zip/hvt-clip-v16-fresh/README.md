# HVT Clip

Automated polish engine for **High Velocity Trading** shorts. Drop a NinjaTrader recording in, get a brand-locked vertical short out — split-stack rendering puts the signal bars front and center because **the bars are the product**.

![Built with Python](https://img.shields.io/badge/python-3.13-blue) ![Powered by FFmpeg](https://img.shields.io/badge/ffmpeg-8.1+-green) ![Status](https://img.shields.io/badge/status-v1.6-success)

---

## What it does

Takes a horizontal NinjaTrader screen recording and produces a polished 1080×1920 vertical short ready for Reels / Shorts / TikTok:

- **Split-stack rendering** — crops chart on top, signal bars on bottom, then stacks them vertically with the bars zone emphasized (42% of output frame)
- **Brand-burned overlays** — hook text, V/HIGH VELOCITY TRADING watermark, CTA outro card all auto-composited
- **Instagram safe-zone compliant** — every overlay positioned so Instagram's UI never covers brand elements
- **Direction-aware accents** — green for longs, red for shorts
- **Background music auto-mix** — drops in any track from `assets/music/hvt_default.mp3`
- **Intro riser support** — auto-fires at t=0 from `assets/sounds/intro_riser.mp3`
- **Persistent hook text** — top overlay stays on screen the entire video

---

## What's new in v1.6

- Hook text persists for the entire video (was: 2.5 seconds)
- Removed LONG/SHORT direction badge from output (was distracting)
- Removed "HVT SIGNALS" text label (clean thin accent line still separates zones)
- Removed URL text from main video (lives only on CTA outro card now)
- Real V/HIGH VELOCITY TRADING logo replaces placeholder watermark
- Redesigned CTA card: pure black/white, "Trade with structure. No emotion." tagline
- Safe-zone-aware positioning so Instagram UI doesn't cover brand elements

---

## Quick start

```bash
# Setup once
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Drop your trade clip
cp ~/Desktop/my_winning_trade.mp4 input/

# Render
python -m src.main input/my_winning_trade.mp4 --direction long --hook "WATCH THE BARS." --branding subtle

# Watch the output
open output/my_winning_trade_hvt_long.mp4
```

---

## Requirements

- **macOS** (tested on Apple Silicon, Tahoe)
- **Python 3.10+** (3.13 recommended)
- **FFmpeg with drawtext filter** — on Apple Silicon, use the [evermeet.cx static build](https://evermeet.cx/ffmpeg/), the default Homebrew formula does not bundle freetype:
 ```bash
 cd ~/Downloads
 curl -L -o ffmpeg.zip https://evermeet.cx/ffmpeg/getrelease/ffmpeg/zip
 unzip -o ffmpeg.zip
 sudo mv ffmpeg /opt/homebrew/bin/ffmpeg
 sudo chmod +x /opt/homebrew/bin/ffmpeg

 # Verify drawtext is available
 ffmpeg -filters 2>&1 | grep drawtext
 ```
- **Pillow** for asset processing (`pip install -r requirements.txt`)

---

## Command-line flags

| Flag | Default | What it does |
|------|---------|--------------|
| `--direction` | (none) | `long` or `short` — drives accent colors |
| `--hook "TEXT"` | (none) | Top overlay text, persists entire video |
| `--branding` | `subtle` | `subtle` / `balanced` / `loud` — watermark opacity + CTA duration |
| `--template` | `hvt` | Template from `config/templates.json` |
| `--chart-ratio` | `0.55` | Top fraction of source = chart zone (tune per NinjaTrader layout) |
| `--markers` | (none) | Optional Premiere CSV for timed ENTRY/TARGET/STOP SFX |
| `--framerate` | `30.0` | Output framerate |
| `--output` | auto | Override output path |

---

## Hook library

Rotate these across posts so the feed feels fresh:

**Long trade hooks:**
```
"WATCH THE BARS."
"CALLED IT. CLEAN."
"ALIGNMENT FIRED."
"GREEN MEANS BUY."
"BOUGHT THE BREAKOUT."
"THREE SIGNALS. ALL GREEN."
"LOCKED THE GAIN."
"STRUCTURE WINS."
```

**Short trade hooks:**
```
"RED MEANS SELL."
"BARS FLIPPED RED."
"TRIPLE RED. CLEAN SHORT."
"FADED THE BREAKOUT."
```

**Either direction:**
```
"WAIT FOR ALIGNMENT."
"NO EMOTION. JUST SIGNALS."
"DISCIPLINE WINS."
```

---

## Folder structure

```
hvt-clip/
├── src/                    # Python source
│   ├── __init__.py
│   ├── main.py             # CLI entry point
│   ├── markers.py          # Premiere marker parser
│   ├── render.py           # ⚡ Core render engine (FFmpeg orchestration)
│   └── templates.py        # Template loader
├── config/
│   └── templates.json      # Brand colors, fonts, overlay specs, audio mix
├── assets/
│   ├── branding/
│   │   ├── hvt_watermark.png     # Real V/HVT logo (white on transparent)
│   │   └── cta_card.png          # 1080×1920 outro card (black/white)
│   ├── music/                    # Drop hvt_default.mp3 here
│   └── sounds/                   # Drop intro_riser.mp3 here (optional)
├── input/                  # Drop your NinjaTrader recordings here
├── output/                 # Polished shorts land here
├── requirements.txt
└── README.md
```

---

## Audio

The system auto-detects and mixes:

| File | Path | Behavior |
|------|------|----------|
| `hvt_default.mp3` | `assets/music/` | Loops under whole video at -22dB |
| `intro_riser.mp3` | `assets/sounds/` | Plays at t=0 only |
| (SFX) | `assets/sounds/` | Fires at Premiere markers (optional) |

Tune music volume in `config/templates.json` → `music.volume_db`.

**Sourcing audio:** royalty-free corporate/ambient tracks from [Pixabay Music](https://pixabay.com/music/), [Free Stock Music](https://www.free-stock-music.com/genre/corporate.html), or YouTube Audio Library. Avoid trap/hype — it conflicts with HVT institutional brand voice.

---

## Brand specs

| Element | Spec |
|---------|------|
| Output resolution | 1080×1920 (vertical 9:16) |
| Output framerate | 30 fps |
| Accent green | `#00FF88` |
| Accent red | `#FF3344` |
| Hook text size | 64px white on black box |
| Watermark opacity | 75% (subtle) / 85% (balanced) / 100% (loud) |
| CTA card duration | 2.0s (subtle) / 2.5s (balanced) / 3.5s (loud) |

---

## License

Internal HVT tool. Not licensed for public reuse without permission.

---

## Built with

Python • FFmpeg • Pillow • Apple Silicon caffeine
